package com.example.new_ui;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
